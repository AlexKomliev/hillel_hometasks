'use strict';

$('body').scrollspy({
    target: '#mainNav',
    offset: 80
});